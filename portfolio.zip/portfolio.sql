-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 02 nov 2018 om 10:47
-- Serverversie: 10.1.30-MariaDB
-- PHP-versie: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfolio`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `admin`
--

CREATE TABLE `admin` (
  `gebruikersnaam` varchar(30) NOT NULL,
  `wachtwoord` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `admin`
--

INSERT INTO `admin` (`gebruikersnaam`, `wachtwoord`) VALUES
('nordinbk', 'portfolio');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `hobby`
--

CREATE TABLE `hobby` (
  `soortHobby` varchar(30) NOT NULL,
  `studentennummer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `hobby`
--

INSERT INTO `hobby` (`soortHobby`, `studentennummer`) VALUES
('voetbal, fitness, zwemmen', 2063206);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `opleiding`
--

CREATE TABLE `opleiding` (
  `locatie` varchar(30) NOT NULL,
  `studentennummer` int(11) NOT NULL,
  `niveau` varchar(30) NOT NULL,
  `soort` varchar(30) NOT NULL,
  `begindatum` date NOT NULL,
  `einddatum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `opleiding`
--

INSERT INTO `opleiding` (`locatie`, `studentennummer`, `niveau`, `soort`, `begindatum`, `einddatum`) VALUES
('Amstelveen', 2063206, 'MBO-4', 'Applicatieontwikkelaar', '2016-08-28', '2020-06-30');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `student`
--

CREATE TABLE `student` (
  `studentennummer` int(11) NOT NULL,
  `geboortedatum` date NOT NULL,
  `woonplaats` varchar(30) NOT NULL,
  `voornaam` varchar(30) NOT NULL,
  `achternaam` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `student`
--

INSERT INTO `student` (`studentennummer`, `geboortedatum`, `woonplaats`, `voornaam`, `achternaam`, `email`) VALUES
(0, '2001-08-18', 'Amsterdam', 'Nordin ', 'Boukazim', '2063206@talnet.nl'),
(2063206, '2001-08-18', 'Amsterdam', 'Nordin ', 'Boukazim', '2063206@talnet.nl');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `talen`
--

CREATE TABLE `talen` (
  `soortTaal` varchar(80) NOT NULL,
  `studentennummer` int(11) NOT NULL,
  `niveau` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `talen`
--

INSERT INTO `talen` (`soortTaal`, `studentennummer`, `niveau`) VALUES
('Nederlands, Engels, Arabisch', 2063206, 'Uitstekend, Goed, Voldoende');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `vaardigheden`
--

CREATE TABLE `vaardigheden` (
  `soortVaardigheden` varchar(99) NOT NULL,
  `studentennummer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `vaardigheden`
--

INSERT INTO `vaardigheden` (`soortVaardigheden`, `studentennummer`) VALUES
('HTML/CSS, Javascript, PHP, C#, Wordpress', 2063206);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werkervaring`
--

CREATE TABLE `werkervaring` (
  `soortBaan` varchar(30) NOT NULL,
  `studentennummer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `werkervaring`
--

INSERT INTO `werkervaring` (`soortBaan`, `studentennummer`) VALUES
('supermarkt medewerker', 2063206);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `admin`
--
ALTER TABLE `admin`
  ADD UNIQUE KEY `gebruikersnaam` (`gebruikersnaam`);

--
-- Indexen voor tabel `hobby`
--
ALTER TABLE `hobby`
  ADD PRIMARY KEY (`soortHobby`),
  ADD UNIQUE KEY `studentennummer` (`studentennummer`),
  ADD KEY `studentennummer_2` (`studentennummer`);

--
-- Indexen voor tabel `opleiding`
--
ALTER TABLE `opleiding`
  ADD PRIMARY KEY (`locatie`),
  ADD UNIQUE KEY `studentennummer` (`studentennummer`),
  ADD KEY `studentennummer_2` (`studentennummer`);

--
-- Indexen voor tabel `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentennummer`),
  ADD KEY `studentennummer` (`studentennummer`);

--
-- Indexen voor tabel `talen`
--
ALTER TABLE `talen`
  ADD PRIMARY KEY (`soortTaal`),
  ADD UNIQUE KEY `studentennummer` (`studentennummer`),
  ADD KEY `studentennummer_2` (`studentennummer`);

--
-- Indexen voor tabel `vaardigheden`
--
ALTER TABLE `vaardigheden`
  ADD PRIMARY KEY (`soortVaardigheden`),
  ADD UNIQUE KEY `studentennummer` (`studentennummer`),
  ADD KEY `studentennummer_2` (`studentennummer`);

--
-- Indexen voor tabel `werkervaring`
--
ALTER TABLE `werkervaring`
  ADD PRIMARY KEY (`soortBaan`),
  ADD UNIQUE KEY `studentennummer` (`studentennummer`),
  ADD KEY `soortBaan` (`soortBaan`),
  ADD KEY `studentennummer_2` (`studentennummer`);

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `hobby`
--
ALTER TABLE `hobby`
  ADD CONSTRAINT `hobby_ibfk_1` FOREIGN KEY (`studentennummer`) REFERENCES `student` (`studentennummer`);

--
-- Beperkingen voor tabel `opleiding`
--
ALTER TABLE `opleiding`
  ADD CONSTRAINT `opleiding_ibfk_1` FOREIGN KEY (`studentennummer`) REFERENCES `student` (`studentennummer`);

--
-- Beperkingen voor tabel `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`studentennummer`) REFERENCES `student` (`studentennummer`);

--
-- Beperkingen voor tabel `talen`
--
ALTER TABLE `talen`
  ADD CONSTRAINT `talen_ibfk_1` FOREIGN KEY (`studentennummer`) REFERENCES `student` (`studentennummer`);

--
-- Beperkingen voor tabel `vaardigheden`
--
ALTER TABLE `vaardigheden`
  ADD CONSTRAINT `vaardigheden_ibfk_1` FOREIGN KEY (`studentennummer`) REFERENCES `student` (`studentennummer`);

--
-- Beperkingen voor tabel `werkervaring`
--
ALTER TABLE `werkervaring`
  ADD CONSTRAINT `werkervaring_ibfk_1` FOREIGN KEY (`studentennummer`) REFERENCES `student` (`studentennummer`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
