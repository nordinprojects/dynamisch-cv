<?php
if(isset($_POST['submit'])){

    $user= 'root'; 
    $pass = ''; 
    $db_conn = new PDO('mysql:host=localhost;dbname=portfolio', $user, $pass);

    $sql = "UPDATE talen SET soortTaal='$_POST[soortTaal]', niveau='$_POST[niveau]'"; 
    $statement = $db_conn->prepare($sql); 
    $statement->execute();

    header('Location: index.php');
}

//update
?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <form method="post">
        <p>Soort Taal:</p>
        <input type="text" name="soortTaal" required><br>
        <p>Niveau</p>
        <input type="text" name="niveau" required/><br>
        <input type="submit" name="submit" value="Bewerken" />
    </form>
</body>
</html>