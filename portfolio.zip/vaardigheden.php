<?php
if(isset($_POST['submit'])){

    $user= 'root'; 
    $pass = ''; 
    $db_conn = new PDO('mysql:host=localhost;dbname=portfolio', $user, $pass);

    $sql = "UPDATE vaardigheden SET soortVaardigheden='$_POST[soortVaardigheden]'"; 
    $statement = $db_conn->prepare($sql); 
    $statement->execute();

    header('Location: index.php');
}


?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <form method="post">
        <p>Soort vaardigheid:</p>
        <input type="text" name="soortVaardigheden" required><br>
        <input type="submit" name="submit" value="Bewerken" />
    </form>
</body>
</html>