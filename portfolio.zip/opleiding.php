<?php
if(isset($_POST['submit'])){

    $user= 'root'; 
    $pass = ''; 
    $db_conn = new PDO('mysql:host=localhost;dbname=portfolio', $user, $pass);

    $sql = "UPDATE opleiding SET soort='$_POST[soort]', niveau='$_POST[niveau]', begindatum='$_POST[begindatum]', einddatum='$_POST[einddatum]', locatie='$_POST[locatie]' "; 
    $statement = $db_conn->prepare($sql); 
    $statement->execute();

    header('Location: index.php');
}


?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <form method="post">
        <p>soort opleiding:</p>
        <input type="text" name="soort" required><br>
        <p>niveau</p>
        <input type="text" name="niveau" required/><br>
        <p>begindatum</p>
        <input type="date" name="begindatum" required/><br>
        <p>einddatum</p>
        <input type="date" name="einddatum" required/><br>
        <p>locatie school</p>
        <input type="text" name="locatie" required/>
        <input type="submit" name="submit" value="Bewerken" />
    </form>
</body>
</html>