<?php
if( isset($_POST['submit'])){
    session_start();
    
    $gebruikersnaam = $_POST['gebruikersnaam'];
    $wachtwoord = $_POST['wachtwoord'];


    include('database.php');
    
    $sql = "SELECT * FROM admin WHERE Gebruikersnaam = :gebruikersnaam"; 
    $statement = $db_conn->prepare($sql); 
    $statement->bindParam(":gebruikersnaam", $gebruikersnaam); 
    $statement->execute(); $database_gegevens = $statement->fetch(PDO::FETCH_ASSOC);
    
    $sql = "SELECT * FROM admin WHERE Wachtwoord = :wachtwoord"; 
    $statement = $db_conn->prepare($sql); 
    $statement->bindParam(":wachtwoord", $wachtwoord); 
    $statement->execute(); $database_gegevens = $statement->fetch(PDO::FETCH_ASSOC);
    
    $gebruikersnaamdb = $database_gegevens['gebruikersnaam'];
    $Wachtwoorddb = $database_gegevens['wachtwoord'];
    
    if($gebruikersnaam==$gebruikersnaamdb && $wachtwoord==$Wachtwoorddb){
        header('location: index.php');

    }
    elseif($gebruikersnaamdb!=$gebruikersnaam || $Wachtwoorddb!=$wachtwoord){
        echo "Het lijkt erop dat uw gegevens niet kloppen, vul nogmaals in.";
    }

    $_SESSION['gebruikersnaam'] = $gebruikersnaam;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin inloggen</title>
    <link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>

<div class="wrapper fadeInDown">
  <div id="formContent">
    
    <h2 class="active"> Log in voor uw CV </h2>
    

    
    <div class="fadeIn first">
      <div class="foto"></div>
      <img src="user.png" alt="Computer Icons Avatar User Login - avatar @kisspng" width="120px" height="120px">
    </div>

    
    <form method="post">
    <div class="loginpagina">
    <div class="naam">
        <p>Gebruikersnaam</p>
    </div>
        <input type="text" name="gebruikersnaam" placeholder="gebruikersnaam" required>
        <p>Wachtwoord</p>
        <input type="password" id="password" class="fadeIn third" name="wachtwoord" placeholder="wachtwoord" required>
        
        <br>
        <input type="submit" name="submit" value="inloggen">
    </form>

    

</body>
</html>