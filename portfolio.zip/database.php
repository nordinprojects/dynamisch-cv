<?php 
$user='root';
$pass= '';
$db_conn = new PDO('mysql:host=localhost;dbname=portfolio', $user, $pass);


?>