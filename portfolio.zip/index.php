<!DOCTYPE html>
<?php
$user= 'root'; 
$pass = ''; 
$db_conn = new PDO('mysql:host=localhost;dbname=portfolio', $user, $pass);

    session_start();
 
    $sql = "SELECT * FROM student WHERE studentennummer";
    $statement = $db_conn->query($sql);
    $row = $statement->fetch();
    
    $sql1 = "SELECT * FROM opleiding WHERE studentennummer";
    $statement1 = $db_conn->query($sql1);
    $row1 = $statement1->fetch();
    
    $sql2 = "SELECT * FROM werkervaring WHERE studentennummer";
    $statement2 = $db_conn->query($sql2);
    $row2 = $statement2->fetch();
    
    $sql3 = "SELECT * FROM vaardigheden WHERE studentennummer";
    $statement3 = $db_conn->query($sql3);
    $row3 = $statement3->fetch();
    
    $sql4 = "SELECT * FROM hobby WHERE studentennummer";
    $statement4 = $db_conn->query($sql4);
    $row4 = $statement4->fetch();

    $sql5 = "SELECT * FROM talen WHERE studentennummer";
    $statement5 = $db_conn->query($sql5);
    $row5 = $statement5->fetch();

    //wijzig buttons

    if (isset($_SESSION['gebruikersnaam'])){
        echo "<a href=logout.php id=logout>uitloggen</a><br>";
        echo "<a href=student.php class=button1> Wijzig </a>";
        echo "<a href=opleiding.php class=button2> Wijzig </a>";
        echo "<a href=vaardigheden.php class=button3> Wijzig </a>";
        echo "<a href=werkervaring.php class=button4> Wijzig </a>";
        echo "<a href=taal.php class=button5> Wijzig </a>";
        echo "<a href=hobby.php class=button6> Wijzig </a>";
        echo "<p id=welcome>Welkom " . $_SESSION['gebruikersnaam'] . "</p><br>";

    }
    //login, contact als ik ben ingelogd
    else{
        echo "<p id=login1><a href=login.php>Admin login</a>";
        echo "<p id=contact><a href=contact.php>Contact Pagina</a>";
    }

     

?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="student">
        <table id="student">

            <tr>
                <div class="wrapper fadeInDown">
  <div id="formContent">
    

    <div class="fadeIn first">
      <div class="foto"></div>
      <img src="user.png" alt="Computer Icons Avatar User Login - avatar @kisspng" width="120px" height="120px">
    </div>
                <h3>Student informatie</h3>
                <p> Naam: <?php echo $row["voornaam"] . " " . $row["achternaam"];?></p>
                <p>Studentennummer: <?php echo $row["studentennummer"];?></p>
                <p>Woonplaats: <?php echo $row["woonplaats"];?></p>
                <p>Geboortedatum: <?php echo $row['geboortedatum'];?></p>
                 <p>E-mail: <?php echo $row['email'];?></p>
            </tr>
            </tr>
        </table>
    </div>

    <div class="opleiding">
        <table id="opleiding">
            <tr>
                <div class="wrapper fadeInDown">
  <div id="formContent">
    

    <div class="fadeIn first">
      <div class="foto"></div>
      <img src="reading.png" alt="Computer Icons Avatar User Login - avatar @kisspng" width="120px" height="120px">
    </div>
                <h3>Opleiding</h3>
                <p>Soort opleiding: <?php echo $row1["soort"]; ?></p>
                <p>Niveau: <?php echo $row1["niveau"]; ?></p>
                <p>Startdatum en einddatum: <?php echo $row1["begindatum"] . " - " . $row1["einddatum"]; ?></p>
                <p>Locatie: <?php echo $row1["locatie"]; ?></p>
            </tr>
        </table>
    </div>

    <div class="werkervaring">
        <table id="werkervaring">
            <tr>
                <div class="wrapper fadeInDown">
  <div id="formContent">
    

    <div class="fadeIn first">
      <div class="foto"></div>
      <img src="werk.png" alt="Computer Icons Avatar User Login - avatar @kisspng" width="120px" height="120px">
    </div>
                <h3>Werkervaring</h3>
                <p>Soort baan: <?php echo $row2["soortBaan"]; ?></p>
                
            </tr>
        </table>
    </div>

    <div class="vaardigheden">
        <table id="vaardigheden">
            <tr>
                <div class="wrapper fadeInDown">
  <div id="formContent">
    

    <div class="fadeIn first">
      <div class="foto"></div>
      <img src="code.png" alt="Computer Icons Avatar User Login - avatar @kisspng" width="120px" height="120px">
    </div>
                <h3>Vaardigheden</h3>
                <p>Vaardigheden: <?php echo $row3["soortVaardigheden"];?></p>
                <div class="block center">
    <section class="skills">
          <progress value="80" max="100"></progress><span>HTML/CSS</span>
          <progress value="45" max="100"></progress><span>Javascript</span>
          <progress value="60" max="100"></progress><span>PHP</span>
          <progress value="40" max="100"></progress><span>C#</span>
          <progress value="80" max="100"></progress><span>Wordpress</span>
                
            </tr>
        </table>
    </div>

    <div class="talen">
         
         <table id="talen">
            <div class="wrapper fadeInDown">
  <div id="formContent">
    

    <div class="fadeIn first">
      <div class="foto"></div>
      <img src="taal.png" alt="Computer Icons Avatar User Login - avatar @kisspng" width="120px" height="120px">
    </div>
                <h3>Talen</h3>
                <p>Talen: <?php echo $row5["soortTaal"];?></p>
                <p>Niveau: <?php echo $row5["niveau"]; ?></p>
                
            </tr>
        </table>
        </div>
        
        <div class="hobby">
        <table id="hobby">
            <tr>
                <div class="wrapper fadeInDown">
  <div id="formContent">
    

    <div class="fadeIn first">
      <div class="foto"></div>
      <img src="sport.png" alt="Computer Icons Avatar User Login - avatar @kisspng" width="120px" height="120px">
    </div>
            
                <h3>Hobby</h3>
                <p>Hobby: <?php echo $row4["soortHobby"];?></p>
                
            </tr>
        </table>
   
    </div>
</body>
</html>