<?php
if(isset($_POST['submit'])){

    $user= 'root'; 
    $pass = ''; 
    $db_conn = new PDO('mysql:host=localhost;dbname=portfolio', $user, $pass);

    $sql = "UPDATE student SET voornaam='$_POST[voornaam]', achternaam='$_POST[achternaam]', woonplaats='$_POST[woonplaats]', geboortedatum='$_POST[geboortedatum]', email='$_POST[email]' "; 
    $statement = $db_conn->prepare($sql); 
    $statement->execute();

    header('Location: index.php');
}
//update

?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <form method="post">
        <p>voornaam:</p>
        <input type="text" name="voornaam" ><br>
        <p>achternaam</p>
        <input type="text" name="achternaam" /><br>
        <p>woonplaats</p>
        <input type="text" name="woonplaats" /><br>
        <p>geboortedatum</p>
        <input type="date" name="geboortedatum" /><br>
        <p>email</p>
        <input type="text" name="email" />
        <input type="submit" name="submit" value="Bewerken" />
    </form>
</body>
</html>