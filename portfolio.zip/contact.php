<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <a href=index.php>Home</a>

    <div class="contactformulier">
        <div class="wrapper fadeInDown">
  <div id="formContent">
    
    
    

    
    <div class="fadeIn first">
      <div class="foto"></div>
      <img src="user.png" alt="Computer Icons Avatar User Login - avatar @kisspng" width="120px" height="120px">
    </div>

    
    
                 <main>
                     <label for="e-mail"><h3 class="textcontact">Naam</h3></label>
                    <input class="emailpost" type="text" name="contact">

                   
                
                    <label for="e-mail"><h3 class="textcontact">E-mail</h3></label>
                    <input class="emailpost" type="text" name="contact">

                    <label for="postcode"><h3 class="textcontact">Telefoon Nummer</h3></label>
                    <input class="emailpost" type="text" name="contact">

                    <label for="opmerking"><h3 class="textcontact">Feedback</h3></label>
                    <input id="opmerking" type="text" name="contact">

                    <div id="verzend">
                            <a id="verzendknop" href="mailto:jouwemail@hotmail.com">Verzenden</a>
                            <div></div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
    
</body>
</html>