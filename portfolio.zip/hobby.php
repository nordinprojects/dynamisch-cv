<?php
if(isset($_POST['submit'])){

    $user= 'root'; 
    $pass = ''; 
    $db_conn = new PDO('mysql:host=localhost;dbname=portfolio', $user, $pass);

    $sql = "UPDATE hobby SET soortHobby='$_POST[soortHobby]'"; 
    $statement = $db_conn->prepare($sql); 
    $statement->execute();

    header('Location: index.php');
}


?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <form method="post">
        <p>Soort Hobby:</p>
        <input type="text" name="soortHobby" required><br>
        <input type="submit" name="submit" value="Bewerken" />
    </form>
</body>
</html>