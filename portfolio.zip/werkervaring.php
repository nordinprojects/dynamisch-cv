<?php
if(isset($_POST['submit'])){

    $user= 'root'; 
    $pass = ''; 
    $db_conn = new PDO('mysql:host=localhost;dbname=portfolio', $user, $pass);

    $sql = "UPDATE werkervaring SET soortBaan='$_POST[soortBaan]'"; 
    $statement = $db_conn->prepare($sql); 
    $statement->execute();
//terug naar home
    header('Location: index.php');
}


?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <form method="post">
        <p>Soort Baan:</p>
        <input type="text" name="soortBaan" required><br>
        <input type="submit" name="submit" value="Bewerken" />
    </form>
</body>
</html>